//based on CodeWizardAVR V2.05.0 www.hpinfotech.com
//written by Michael Jahrer + Automatic Program Generator help
//dev date start:2021.05.30  now:2022.12.28
//Chip type               : ATmega324PA
//AVR Core Clock frequency: 12,000000 MHz

#include <mega324a.h>
#include <sdcard.h>

#ifndef UDRE
#define UDRE 5
#endif
#define DATA_REGISTER_EMPTY (1<<UDRE)

// Write a character to the USART0 Transmitter
#ifndef _DEBUG_TERMINAL_IO_
#define _ALTERNATE_PUTCHAR_
#pragma used+
void putchar(char c)
{
    while ((UCSR0A & DATA_REGISTER_EMPTY)==0)
        ;
    UDR0=c;
}
#pragma used-
#endif


#include <stdio.h>
#include <string.h>
#include <delay.h>
#include <alcd.h>

// Timer1 overflow interrupt frequency [Hz]
#define T1_OVF_FREQ 100
// Timer1 clock prescaler value
#define T1_PRESC 1024L
// Timer1 initialization value after overflow
#define T1_INIT (0x10000L-(_MCU_CLOCK_FREQUENCY_/(T1_PRESC*T1_OVF_FREQ)))

#define ADC_VREF_TYPE 0x00
//int  interruptCnt=0;

char state0,state1,state0Last=1, state1Last=1, isIncreased=0, isDecreased=0;
// Pin change 0-7 interrupt service routine
interrupt [PC_INT0] void pin_change_isr0(void)  // interrupt is used for handling rotary shaft encoder changes
{
    // Place your code here
    state0 = ((PINA&0x40)>>6); // incremental encoder switch: position0
    state1 = ((PINA&0x20)>>5); // incremental encoder switch: position1
    if (state0==1 && state1==1 && state0Last==1 && state1Last==0)
    {
        isIncreased=0;
        isDecreased=1;
    }
    if (state0==1 && state1==1 && state0Last==0 && state1Last==1)
    {
        isIncreased=1;
        isDecreased=0;
    }
    state0Last=state0; // store last state of PA.6
    state1Last=state1; // store last state of PA.5
}

// Timer1 overflow interrupt service routine (for sdcard only)
interrupt [TIM1_OVF] void timer1_ovf_isr(void)
{
    TCNT1H=T1_INIT>>8;
    TCNT1L=T1_INIT&0xFF;          
    //PORTB |= 0x08;  // beeper on
    //delay_ms(1);
    //PORTB &= 0xF7;  // beeper off 
    disk_timerproc();
}

// === global variables ===
// per-cell calibration factors (compensate resistor volt divider inaccuracies)
// this is needed also with 0.1% resistors
// we measure here 1mV voltages
// this needs to be calibrated for each BMS cell-by-cell on the device
#define sc0 .0058
eeprom float corr[16] = {sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0,sc0};

//eeprom 
eeprom float cellMinBeep=2.8, cellMaxBeep=3.5, cellDiffBeep=0.2, currentMax=100;
eeprom float cellMaxRelaisOn=3.45, cellMaxRelaisOff=3.4;
eeprom float ampScaleDischarge=0.14,ampScaleCharge=0.14,ampOffset=20;
eeprom float energyWh=132,energykWh=0,SOCfullV=3.4,SOCfullA=5;
eeprom unsigned int id=0, uartLogInterval=0, sdcardLogInterval=0;

//char dbg=0;
float oneLoopSec=1.565;// 313/200 // 20=UART=SDCARD Interval. 5:13=313s and 200 counts
float kWhSum=0.0, kWhSumMax=0.0; //TODO:SOC

// === main function ===
void main(void)
{
    // Declare your local variables here
    unsigned int cnt0=0, uartCnt=0, sdcardCnt=0;
    float amp[2],ma[16],cellV[16],sum,cellMin,cellMax,mean,a,chargeMA=0.0,dischargeMA=0.0,avgCell=0,SOC=100;
    float accuCapacity=0,sumOfDischargedEnergy=0;
    char s[64],*sPtr=0,increased,N=16,selected0=0,selected1=0,switchReleased=0,ampDebug=0;
    signed char mainSelect=0, mainSelectOld=-1,cellID=0,sw,cellMaxIdx=-1,cellMinIdx=-1,cellCnt=0,pChange=0;
    signed int i, j, adcSigned;
    long int gCnt=0;
    
    // sdcard vars
    unsigned char disk_status;
    unsigned char sdcardErrCode=0;//cc
    FRESULT res;
    FATFS drive;
    //FRESULT rr; 
    //char text[]="test123xx\n";
    unsigned int nbytes;
    FIL file;

    for (i=0; i < N; i++)
        ma[i] = 0.0;  // set moving averages of voltages to 0.0

    // Crystal Oscillator division factor: 1
    #pragma optsize-
    CLKPR=0x80;
    CLKPR=0x00;
    #ifdef _OPTIMIZE_SIZE_
    #pragma optsize+
    #endif

    accuCapacity=(energyWh*1e-3+energykWh);
    
    PORTA=0x00;
    DDRA=0x00;
    PORTB=0x00;
    DDRB=0x08; // PortB 3=out [3]=beeper
    PORTC=0x00;
    DDRC=0x08; // PortC 3=out [3]=multiplexer enable
    PORTD=0x00;
    DDRD=0xF1;  // PortD 0,4,5,6,7=out,  [4,5,6,7]=mulitplexer selection, [0]=Relais
    // do not connect anything to PortD.2  Its used as WP in SDcard config!!
    
    // Timer/Counter 0 initialization
    TCCR0A=TCCR0B=TCCR0B=TCNT0=OCR0A=OCR0B=0x00;
    
    // Timer/Counter 1 initialization
    // Clock source: System Clock
    // Clock value: 12000,000 kHz
    // Mode: Normal top=0xFFFF
    // Timer1 Overflow Interrupt: On
    TCCR1A=0x00;
    TCCR1B=0x02;
    TCNT1H=0x00;
    TCNT1L=0x00;
    ICR1H=0x00;
    ICR1L=0x00;
    OCR1AH=0x00;
    OCR1AL=0x00;
    OCR1BH=0x00;
    OCR1BL=0x00;

    // Timer/Counter 2 initialization
    ASSR=TCCR2A=TCCR2B=TCNT2=OCR2A=OCR2B=0x00;
    
    // External Interrupt(s) initialization
    // Interrupt on any change on pins PCINT0-7: On  <-- used for rotary shaft encoder
    EICRA=0x00;
    EIMSK=0x00;
    PCMSK0=0x60;
    PCICR=0x01;
    PCIFR=0x01;  
    // Timer/Counter 0 Interrupt(s) initialization
    TIMSK0=0x00;  // off

    // Timer/Counter 1 Interrupt(s) initialization
    // initialize Timer1 overflow interrupts in Mode 0 (Normal)  <-- used for sdcard
    TCCR1A=0x00;
    // clkio/1024
    TCCR1B=(1<<CS12)|(1<<CS10);
    // timer overflow interrupts will occur with 100Hz frequency
    TCNT1H=T1_INIT>>8;
    TCNT1L=T1_INIT&0xFF;
    // enable Timer1 overflow interrupt
    TIMSK1=(1<<TOIE1) | (1<<TOIE0);

    // Timer/Counter 2 Interrupt(s) initialization
    TIMSK2=0x00;  // off

    // USART1 initialization
    UCSR1B=0x00;

    // USART0 initialization: data stream output
    // Communication Parameters: 8 Data, 1 Stop, No Parity
    // USART0 Receiver: Off
    // USART0 Transmitter: On
    // USART0 Mode: Asynchronous
    // USART0 Baud Rate: 9600
    UCSR0A=0x00;
    UCSR0B=0x08;
    UCSR0C=0x06;
    UBRR0H=0x00;
    UBRR0L=0x4D;

    // Analog Comparator initialization
    // Analog Comparator: Off
    // Analog Comparator Input Capture by Timer/Counter 1: Off
    ACSR=0x80;
    ADCSRB=0x00;
    DIDR1=0x00;

    // ADC initialization
    DIDR0=0x00;
    ADMUX=0x80;
    ADCSRA=0x85;

    // SPI initialization
    SPCR=0x00;

    // TWI initialization
    TWCR=0x00;

    // Alphanumeric LCD initialization
    // Connections specified in the
    // Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
    // RS - PORTC Bit 0
    // RD - PORTC Bit 1
    // EN - PORTC Bit 2
    // D4 - PORTC Bit 4
    // D5 - PORTC Bit 5
    // D6 - PORTC Bit 6
    // D7 - PORTC Bit 7
    // Characters/line: 20
    lcd_init(20);
    
    delay_ms(100);
    
    PORTB &= 0xF7;  // beeper off 
    PORTB |= 0x08;  // beeper on: beep on startup
    delay_ms(200);
    PORTB &= 0xF7;  // beeper off 
                
    //globally enable interrupts
    #asm("sei")

    
    delay_ms(100);
    // === SD card test ===
    /*if (0)
    //while (1)
    {
        lcd_gotoxy(0,0);
        lcd_putsf("SDtest ...");
        
        //interruptCnt=1;
        disk_status=disk_initialize(0); // initialize SPI interface and card driver
        cc = disk_status;
        sprintf(s,"stat:%d ",cc);
        lcd_puts(s);
        delay_ms(500);

        if (disk_status & STA_NODISK)
            lcd_putsf("Card not present");
        else
        {
            if (disk_status & STA_NOINIT)
                lcd_putsf("Disk init failed");
            else
            {
                if (disk_status & STA_PROTECT)
                    lcd_putsf("Card write protected");
                else
                    lcd_putsf("Init OK");
            }
            if ((res=f_mount(0,&drive))==FR_OK)
            {
                lcd_gotoxy(0,1);
                lcd_putsf("mounted OK");
                if ((res=f_open(&file,"0:/log.csv",FA_OPEN_ALWAYS | FA_WRITE))==FR_OK)
                {
                    sprintf(s,"res=%d",res);
                    lcd_puts(s);                                 
                    res = f_lseek(&file, file.fsize); // seek to end of file
                    for (i=0; i < 20; i++)
                    {
                        lcd_gotoxy(0,0);
                        if ((res=f_write(&file,text,sizeof(text)-1,&nbytes))==FR_OK)
                            lcd_putsf(" written.");
                        else
                            lcd_putsf(" writeError.");  
                    }
                }
                if ((res=f_close(&file))==FR_OK)
                    lcd_putsf(" closeOK.");
                else
                    lcd_putsf(" closeERR.");
            }
            else
            {
                sprintf(s,"ERR res=%d",res);
                lcd_puts(s);
            }
        }
        //while(1);
        delay_ms(1000);
    }*/
    /*i=0;
    while (1)  // main loop forever. computation time: approx 1.6[s] per loop
    {
        sw = ((PINA&0x80)>>7);     // incremental encoder switch: button
        if (isIncrease)
        {
            i++;
            isIncrease=0;
        }
        if (isDecrease)
        {
            i--;
            isDecrease=0;
        }
        
        lcd_clear();
        sprintf(s,"%d sw=%d s0=%d s1=%d",i,sw,state0,state1);
        s[20]=0;
        lcd_gotoxy(0,0);
        lcd_puts(s);              
        delay_ms(100);
    } */
    while (1)  // main loop forever. computation time: approx 1.6[s] per loop
    {          // main loop: sample all 16 cell volates + current shunt pos+neg current
        cnt0=0;                    // counter for exit menu
        sw = ((PINA&0x80)>>7);     // incremental encoder switch: button
        for (i=0; i < 2; i++)      // read shunt current: amp[0]=charge, amp[1]=discharge
        {
            ADMUX = 0x80 + i + 1;    // select input pin i=0:PA1 or i=1:PA2
            delay_ms(1);             // wait for settle..
            mean=0.0;                // init average to 0.0
            for (j=0; j < 1000; j++) // 1000x ADC conversion -> calc mean -> more accuracy!
            {
                delay_us(10);               // delay needed for the stabilization of the ADC input voltage
                ADCSRA|=0x40;               // start the AD conversion
                while ((ADCSRA & 0x10)==0); // wait for the AD conversion to complete
                ADCSRA|=0x10;               // clear ADIF flag
                adcSigned = ADCW;           // assign result
                mean += (float)adcSigned;   // add to average
            }
            amp[i] = mean*1e-3;               // result is average of 1000 ADC conversions
            if (sw==0 && ((PINA&0x80)>>7)==1) // software controlled switch: released?
            {
                switchReleased=1;             // switch released
                break;                        // exit for loop
            }
            sw = ((PINA&0x80)>>7);  // incremental encoder switch: button
        }
        ADMUX = 0x80;         // select input PA0
        sw = ((PINA&0x80)>>7);// incremental encoder switch: button
        
        for (i=0; i < N; i++)  // read cell voltages, N=16 total
        {
            PORTC|=0x08;   // PORTC.3=1 -> disable multiplexer during change
            PORTD=(i<<4)|(PORTD&0x0F);  // change multiplexer channels
            PORTC&=0xF7;   // PORTC.3=0 -> enable multiplexer
            delay_us(100); // wait for settle..
            mean=0.0;      // init average to 0.0
            for (j=0; j < 1000; j++) // 1000x ADC conversion -> calc mean -> more accuracy!
            {
                delay_us(10);               // delay needed for the stabilization of the ADC input voltage
                ADCSRA|=0x40;               // start the AD conversion
                while ((ADCSRA & 0x10)==0); // wait for the AD conversion to complete
                ADCSRA|=0x10;               // clear ADIF flag
                adcSigned = ADCW;           // assign result
                mean += (float)adcSigned;   // add to average
            }
            ma[i] = mean*1e-3;                // store result: average of 1000 ADC conversions
            if (sw==0 && ((PINA&0x80)>>7)==1) // software controlled switch: released?
            {
                switchReleased=1;             // switch released
                break;                        // exit for loop
            }
            sw = ((PINA&0x80)>>7);  // incremental encoder switch: button
        }
        PORTD&=0x0F; // set back mux to 0 (set pins on PortD 4,5,6,7 to 0)
        
        sum=0.0; // pack voltage
        cellMin = 5.0;  // min cell Volt
        cellMax = 0.0; // max cell Volt
        avgCell = 0.0; // average cell Volt
        cellCnt = 0;
        for (i=0; i < N; i++)  // calculate pack voltage: sum of all cell voltages
        {
            cellV[i] = ma[i]*corr[i];  // Volt = avgADC * correction
            if (cellV[i] < 0.1)  // truncate too small cells (unconnected ones)
                cellV[i] = 0.0;  // to 0
            else
            {       
                cellCnt++;
                sum += cellV[i];        // pack voltage sum
                if (cellMin>cellV[i])   // detect lowest cell volt
                {
                    cellMin = cellV[i];
                    cellMinIdx = i;
                }
                if (cellMax<cellV[i])   // detect highest cell volt
                {
                    cellMax = cellV[i];
                    cellMaxIdx = i;
                }
            }
        }
        if (cellCnt>0)
            avgCell = sum/(float)cellCnt;
        /*if(dbg) // debug: to calculate the correction factor with a connected pre-balanced battery pack
        {       // make a photo of the 4x40 display and enter the correction values in begin section
            lcd_clear();
            sprintf(s,"%1.1f%1.1f%1.1f%1.1f",cellV[0]/corr[0],cellV[1]/corr[1],cellV[2]/corr[2],cellV[3]/corr[3]);
            s[20]=0;
            lcd_gotoxy(0,0);
            lcd_puts(s);
            sprintf(s,"%1.1f%1.1f%1.1f%1.1f",cellV[4]/corr[4],cellV[5]/corr[5],cellV[6]/corr[6],cellV[7]/corr[7]);
            s[20]=0;
            lcd_gotoxy(0,1);
            lcd_puts(s);
            sprintf(s,"%1.1f%1.1f%1.1f%1.1f",cellV[8]/corr[8],cellV[9]/corr[9],cellV[10]/corr[10],cellV[11]/corr[11]);
            s[20]=0;
            lcd_gotoxy(0,2);
            lcd_puts(s);
            sprintf(s,"%1.1f%1.1f%1.1f%1.1f",cellV[12]/corr[12],cellV[13]/corr[13],cellV[14]/corr[14],cellV[15]/corr[15]);
            s[20]=0;
            lcd_gotoxy(0,3);
            lcd_puts(s);
        }*/
        // normal mode: display cell voltages, max diff
        {
            // === display numbers and content ===
            lcd_clear();                          
            a = (amp[0]-amp[1]+ampOffset);
            a *= (a > 0.0 ? ampScaleCharge : ampScaleDischarge);
              
            if (gCnt % 10 == 0)  // every 10th loop display all cell voltages
            {
                sprintf(s,"%1.2f %1.2f %1.2f %1.2f",cellV[0],cellV[1],cellV[2],cellV[3]);
                s[20]=0;
                lcd_gotoxy(0,0);
                lcd_puts(s);
                sprintf(s,"%1.2f %1.2f %1.2f %1.2f",cellV[4],cellV[5],cellV[6],cellV[7]);
                s[20]=0;
                lcd_gotoxy(0,1);
                lcd_puts(s);
                sprintf(s,"%1.2f %1.2f %1.2f %1.2f",cellV[8],cellV[9],cellV[10],cellV[11]);
                s[20]=0;
                lcd_gotoxy(0,2);
                lcd_puts(s);
                sprintf(s,"%1.2f %1.2f %1.2f %1.2f",cellV[12],cellV[13],cellV[14],cellV[15]);
                s[20]=0;
                lcd_gotoxy(0,3);
                lcd_puts(s);
            } 
            else
            {
                if (ampDebug)  // for calibration shunt current measurement
                {
                    //calc: a = (amp[0]-amp[1]+ampOffset);
                    //calc: a *= (a > 0.0 ? ampScaleCharge : ampScaleDischarge);
            
                    // calc moving average of charge/discharge to smooth it
                    chargeMA = (chargeMA==0.0?amp[0]:chargeMA*0.9+0.1*amp[0]);
                    dischargeMA = (dischargeMA==0.0?amp[1]:dischargeMA*0.9+0.1*amp[1]);
                    lcd_clear();
                    sprintf(s,"I=%1.3fA",a); 
                    lcd_gotoxy(0,0);
                    s[20]=0;
                    lcd_puts(s); 
                    sprintf(s,"ch=%1.1f di=%1.1f",amp[0],amp[1]); 
                    lcd_gotoxy(0,1);
                    s[20]=0;
                    lcd_puts(s); 
                    sprintf(s,"chMA=%1.3f diMA=%1.3f",chargeMA,dischargeMA); 
                    lcd_gotoxy(0,2);
                    s[20]=0;
                    lcd_puts(s);
                    sprintf(s,"of=%1.2f a=%1.1f",ampOffset,(amp[0]-amp[1]+ampOffset)); 
                    lcd_gotoxy(0,3);
                    s[20]=0;
                    lcd_puts(s);
                }                                                                                                                                                          
                else
                {
                    sprintf(s,"%1.1fV %1.1fA %1.2fkW",sum,a,sum*a*1e-3); // line0: Volt,Ampere,Watt
                    lcd_gotoxy(0,0);
                    s[20]=0;
                    lcd_puts(s); 
                    
                    sprintf(s,"diff:%1.3f  %d %d",cellMax-cellMin,
                                (sdcardLogInterval!=0?sdcardLogInterval-(sdcardCnt % sdcardLogInterval):0),
                                (uartLogInterval!=0?uartLogInterval-(uartCnt % uartLogInterval):0) );  // line1:cellDiff, cnts remaining
                    
                    lcd_gotoxy(0,1);
                    s[20]=0;
                    lcd_puts(s); 
                    
                    sprintf(s,"%1.3f=%d %1.3f=%d",cellMin,cellMinIdx+1,cellMax,cellMaxIdx+1);  // line2: cell min, cell max
                    lcd_gotoxy(0,2);
                    s[20]=0;
                    lcd_puts(s); 
                                                   
                    // energy, SOC calculation                               
                    if (kWhSumMax < kWhSum)
                        kWhSumMax=kWhSum;     // highest state of energy
                    sumOfDischargedEnergy=kWhSumMax-kWhSum;
                    if (avgCell >= SOCfullV && a < SOCfullA)// cell volt over thresh and current below thresh
                        SOC = SOC*0.99+0.01*100.0;          // let SOC climb to 100%
                    else // somewhere between
                        SOC = 100.0*(1.0-sumOfDischargedEnergy / accuCapacity);
                    if (SOC<0.0)
                        SOC=0.0;
                    if (SOC>100.0)
                        SOC=100.0;
                    sprintf(s,"kWh%1.1f %1.1f %1.1f%%",kWhSum,sumOfDischargedEnergy,SOC); // line3: SOC related things
                    lcd_gotoxy(0,3);
                    s[20]=0;
                    lcd_puts(s); 
                }
            }
            // integral of charged/discharded energy. P=U*I  U=sum, I=a
            kWhSum += 1e-3*sum*a*oneLoopSec*2.77777e-4; // 1/3600=2.77777e-4
            gCnt++;
            
            // === sdcard data logging ===
            sdcardCnt++; 
            if (sdcardLogInterval != 0)
                if (sdcardCnt % sdcardLogInterval == 0)
                {
                    sdcardCnt = 0;
                    sdcardErrCode = 0;
                    disk_status=disk_initialize(0); // initialize SPI interface and card driver
                    if (disk_status & STA_NODISK)
                        sdcardErrCode = 1;//lcd_putsf("Card not present");
                    else
                    {
                        if (disk_status & STA_NOINIT)
                            sdcardErrCode = 2;//lcd_putsf("Disk init failed");
                        else
                        {
                            if (disk_status & STA_PROTECT)
                                sdcardErrCode = 3;//lcd_putsf("Card write protected");
                        }
                        if (sdcardErrCode == 0)
                        {
                            if ((res=f_mount(0,&drive))==FR_OK)
                            {
                                if ((res=f_open(&file,"0:/log.csv",FA_OPEN_ALWAYS | FA_WRITE))==FR_OK)
                                {
                                    res = f_lseek(&file, file.fsize); // seek to end of file
                                    sprintf(s,"%d,%1.3f,%1.3f",id,sum,a); // id,voltSum,ampere
                                    res=f_write(&file,s,strlen(s),&nbytes);
                                    for (i=0; i < N; i++) // all cell voltages
                                    {
                                        sprintf(s,",%1.3f",cellV[i]);  // cellVolt
                                        res=f_write(&file,s,strlen(s),&nbytes);
                                    }
                                    sprintf(s,"\r\n");
                                    res=f_write(&file,s,strlen(s),&nbytes);
                                }
                                if ((res=f_close(&file))==FR_OK)
                                    ;//lcd_putsf(" closeOK.");
                                else
                                    sdcardErrCode = 4;//lcd_putsf(" closeERR.");
                            }
                            //else
                            //{
                            //    sprintf(s,"ERR res=%d",res);
                            //    lcd_puts(s);
                            //}
                        }
                    }
                }
            
            // === UART data logging ===
            uartCnt++; 
            if (uartLogInterval != 0)
                if (uartCnt % uartLogInterval == 0)
                {
                    uartCnt = 0;
                    sprintf(s,"%d,%1.3f,%1.3f",id,sum,a); // id,voltSum,ampere
                    sPtr = s;
                    while((*sPtr)!=0)
                    {
                        putchar(*sPtr);
                        sPtr++;
                    }
                    for (i=0; i < N; i++) // all cell voltages
                    {
                        sprintf(s,",%1.3f",cellV[i]);  // cellVolt
                        sPtr = s;
                        while((*sPtr)!=0)
                        {
                            putchar(*sPtr);
                            sPtr++;
                        }
                    }
                    putchar('\r');// windoof line ending
                    putchar('\n');// normal line ending
                }
            
            // === relais control ===
            if (cellMax >= cellMaxRelaisOn)
                PORTD |= 0x01;  // relais on
            if (cellMax < cellMaxRelaisOff)
                PORTD &= 0xFE;  // relais ff
            
            // === beeper control ===
            if (cellMax>=cellMaxBeep || cellMin<=cellMinBeep || cellMax-cellMin>=cellDiffBeep || a>=currentMax || a<=-currentMax)
                PORTB |= 0x08;  // beeper on 
            else
                PORTB &= 0xF7;  // beeper off 
            
            // === control output FET ===
            /*if (outFET)
            {
                PORTB |= 0x04;  // FET on 
                PORTB &= 0xF7;  // beeper off 
                if (cellMax > cellVoltMax ||           // a cell above max volt  OR 
                    cellMin < cellVoltMin ||           // a cell below min volt  OR
                    (cellMax-cellMin)>cellVoltDiffMax) // cellDifference above max volt  OR
                    {
                        if (outFETCnt > 2)  // this is because of spikes
                            outFET=0; // switch off
                        outFETCnt++;
                    }
            }
            else
            {                       
                outFETCnt = 0;
                PORTB &= 0xFB;  // FET off
                PORTB |= 0x08;  // beeper on 
                if (cellMax < cellVoltMaxRecover && cellMax < cellVoltMax &&      // max cell below recover volt AND
                    cellMin > cellVoltMinRecover && cellMin > cellVoltMin &&      // min cell above recover volt  AND
                    (cellMax-cellMin)<cellVoltDiffMaxRecover && (cellMax-cellMin)<cellVoltDiffMax) // diff above recover
                    outFET=1; // switch on
            }*/
        
            // ==== software controlled encoder switch ====
            if (switchReleased)
            {             
                lcd_clear();                                                                  
                switchReleased=0;
                while(1)  // exit: press button for 1s
                {                                 
                    if ((mainSelect != mainSelectOld) || selected0==1)
                    {
                        lcd_gotoxy(0,0);                                                  
                        sprintf(s,"                    ");lcd_puts(s);
                        lcd_gotoxy(0,0);
                        if (mainSelect==0 && selected0==0) lcd_putsf("0 calibrate");
                        if (mainSelect==0 && selected0==1)
                        {
                            sprintf(s,"0 calibr id=%d",cellID+1);
                            lcd_puts(s);
                            if(selected1==1)
                            {
                                if (cellID==N)  // special:set all cell voltages to a constant
                                {               
                                    lcd_gotoxy(0,1);
                                    lcd_putsf("calibrate all cells");
                                    lcd_gotoxy(0,2);
                                    sprintf(s,"%1.3f[V]",avgCell); 
                                    lcd_puts(s);
                                    if (pChange)
                                        for (i=0; i < N; i++)  // calculate pack voltage: sum of all cell voltages
                                            corr[i] = avgCell/ma[i]; //cellV[i] = ma[i]*corr[i];  // Volt = avgADC * correction
                                }   
                                else  // single cell calibration
                                {
                                    i = cellID;
                                    PORTC|=0x08; // PORTC.3=1, mux disable
                                    PORTD=(i<<4)|(PORTD&0x0F);  // change multiplexer channels
                                    PORTC&=0xF7; // PORTC.3=0, mux enable
                                    delay_us(100);//settle..
                                    mean=0.0;
                                    for (j=0; j < 500; j++)  // 500x ADC conversion -> calc mean (why 500? rotary sens)
                                    {
                                        delay_us(10); // delay needed for the stabilization of the ADC input voltage
                                        ADCSRA|=0x40; // start the AD conversion
                                        while ((ADCSRA & 0x10)==0); // wait for the AD conversion to complete
                                        ADCSRA|=0x10;
                                        adcSigned = ADCW;            
                                        mean += (float)adcSigned;
                                    }
                                    if (pChange)
                                        ma[i] = mean*2e-3;
                                    lcd_gotoxy(0,1);
                                    sprintf(s,"%1.3f[V] %1.6f",ma[i]*corr[i],corr[i]); 
                                    lcd_puts(s);
                                }                                                 
                            }
                        }
                        if (mainSelect==1) {sprintf(s,"%d cellMinBeep=%1.2f",mainSelect,cellMinBeep);lcd_puts(s);}
                        if (mainSelect==2) {sprintf(s,"%d cellMaxBeep=%1.2f",mainSelect,cellMaxBeep);lcd_puts(s);}
                        if (mainSelect==3) {sprintf(s,"%d cellDiffBeep=%1.2f",mainSelect,cellDiffBeep);lcd_puts(s);}
                        if (mainSelect==4) {sprintf(s,"%d currMax=%1.2f",mainSelect,currentMax);lcd_puts(s);}
                        if (mainSelect==5) {sprintf(s,"%d relaisOn=%1.2f",mainSelect,cellMaxRelaisOn);lcd_puts(s);}
                        if (mainSelect==6) {sprintf(s,"%d relaisOff=%1.2f",mainSelect,cellMaxRelaisOff);lcd_puts(s);}
                        if (mainSelect==7) {sprintf(s,"%d shuntCha=%1.3f",mainSelect,ampScaleCharge);lcd_puts(s);}
                        if (mainSelect==8) {sprintf(s,"%d shuntDis=%1.3f",mainSelect,ampScaleDischarge);lcd_puts(s);}
                        if (mainSelect==9) {sprintf(s,"%d shuntOff=%1.3f",mainSelect,ampOffset);lcd_puts(s);}
                        if (mainSelect==10) {sprintf(s,"%d ampDebug=%d",mainSelect,ampDebug);lcd_puts(s);}      
                        if (mainSelect==11) {sprintf(s,"%d energyWh=%1.0f",mainSelect,energyWh);lcd_puts(s);}
                        if (mainSelect==12) {sprintf(s,"%d energykWh=%1.0f",mainSelect,energykWh);lcd_puts(s);}
                        if (mainSelect==13) {sprintf(s,"%d SOCfullV=%1.3f",mainSelect,SOCfullV);lcd_puts(s);}
                        if (mainSelect==14) {sprintf(s,"%d SOCfullA=%1.1f",mainSelect,SOCfullA);lcd_puts(s);}
                        if (mainSelect==15) {sprintf(s,"%d uartInterval=%d",mainSelect,uartLogInterval);lcd_puts(s);}
                        if (mainSelect==16) {sprintf(s,"%d sdInterval=%d",mainSelect,sdcardLogInterval);lcd_puts(s);}
                        if (mainSelect==17) {sprintf(s,"%d id=%d",mainSelect,id);lcd_puts(s);}
                        s[20]=0;
                    }      
                    mainSelectOld = mainSelect;
                    pChange=0;
                    if (isIncreased==1 || isDecreased==1)
                    {
                        pChange=1;
                        if (isIncreased==1)
                        {
                            isIncreased=0;
                            increased=1;
                        }
                        if (isDecreased==1)
                        {
                            isDecreased=0;
                            increased=0;
                        }
                        if (selected0 == 1)
                        {
                            if (mainSelect==0)
                            {
                                if (selected1==0) {if (increased){cellID++; if (cellID>=N+1) cellID=0;} else {cellID--; if (cellID<0) cellID=N;}}
                                if (selected1==1) {if (cellID==N) avgCell+=(increased?0.002:-0.002); else corr[cellID]+=(increased?3e-6:-3e-6);}
                            }
                            if (mainSelect==1) cellMinBeep += (increased?1e-2:-1e-2);
                            if (mainSelect==2) cellMaxBeep += (increased?1e-2:-1e-2);
                            if (mainSelect==3) cellDiffBeep += (increased?1e-2:-1e-2);
                            if (mainSelect==4) currentMax += (increased?1e-1:-1e-1);
                            if (mainSelect==5) cellMaxRelaisOn += (increased?1e-2:-1e-2);
                            if (mainSelect==6) cellMaxRelaisOff += (increased?1e-2:-1e-2);
                            if (mainSelect==7) ampScaleCharge += (increased?1e-3:-1e-3);
                            if (mainSelect==8) ampScaleDischarge += (increased?1e-3:-1e-3);
                            if (mainSelect==9) ampOffset += (increased?1e-1:-1e-1);
                            if (mainSelect==10) ampDebug += (increased?1:-1); 
                            if (mainSelect==11) {energyWh += (increased?1:-1); accuCapacity=(energyWh*1e-3+energykWh);}
                            if (mainSelect==12) {energykWh += (increased?1:-1); accuCapacity=(energyWh*1e-3+energykWh);}
                            if (mainSelect==13) SOCfullV += (increased?5e-3:-5e-3);
                            if (mainSelect==14) SOCfullA += (increased?1e-1:-1e-1);
                            if (mainSelect==15) uartLogInterval += (increased?1:-1);
                            if (mainSelect==16) sdcardLogInterval += (increased?1:-1);
                            if (mainSelect==17) id += (increased?1:-1);
                        }
                        else 
                            mainSelect+=(increased?1:-1);
                    }
                    if (mainSelect < 0) mainSelect=17;
                    if (mainSelect > 17) mainSelect=0;
                    
                    cnt0 = 0;
                    while(((PINA&0x80)>>7)==0)  // exit countdown
                    {
                        cnt0++;
                        if (cnt0 > 500)
                            cnt0 = 500;
                        sum = (500-cnt0)*0.002; 
                        sprintf(s,"save+exit %1.2f[s]",sum);
                        s[20]=0;
                        lcd_gotoxy(0,3);
                        lcd_puts(s);
                    }
                    if (cnt0 == 500) // button long pressed -> exit
                    {
                        mainSelectOld=-1;
                        mainSelect=0;
                        selected0=0;
                        selected1=0;                       
                        cellID=0;
                        break;           
                    }
                    if (cnt0 > 0) // button short pressed -> selected
                    {            
                        if (selected0 == 1)
                            selected1 = 1;
                        selected0 = 1;
                    }
                    delay_ms(10);
                }
            } // software controlled encoder switch
        } // if() normal mode / dbg mode
    } // while(1)
} // main()
